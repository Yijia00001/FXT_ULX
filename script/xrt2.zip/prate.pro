pro prate, saveps=saveps
; find net count rate and scale it to intrinsic luminosity

files = file_search('./*33469*/ulx.pi')

n_obs = n_elements(files)
date = dblarr(n_obs)
rate = dblarr(n_obs)
rate_err = dblarr(n_obs)
hr = dblarr(n_obs) ; 1-10 keV / 0.3-1 keV
hr_err = dblarr(n_obs, 2)
bkgfrac = dblarr(n_obs)

; first load the RMF file and get channel range for 0.3-10 keV
; E_MIN: channel
; 0.2 keV: 20
; 0.3 keV: 30
; 0.75 keV: 75
; 1.0 keV: 100
; 1.5 keV: 150
; 2 keV: 200
; 10 keV: 1000
; checked that all RMF files are the same

ebound = [30, 100, 200] ; energy bounds
tot_exp = 0d

for i = 0L, n_obs - 1L do begin
	fsrc = files[i]
	dir = file_dirname(fsrc)
	fbkg = dir + '/ulx_bkg.pi'
	
	dsrc = mrdfits(fsrc, 1, shdr, /silent)
	dbkg = mrdfits(fbkg, 1, bhdr, /silent)
	exptime = sxpar(shdr, 'EXPOSURE')
	tot_exp = tot_exp + exptime
	
	scales = sxpar(shdr, 'BACKSCAL')
	scaleb = sxpar(bhdr, 'BACKSCAL')
	f = scales / scaleb
	
	ss = dsrc.counts
	bb = dbkg.counts
	
	cs = total(ss[ebound[0]:ebound[1] - 1L])
	ch = total(ss[ebound[1]:ebound[2] - 1L])
	
	if ch ne 0 then begin
		hrlow, ch, cs, r, r0, r1
		hr[i] = r
		hr_err[i, *] = [r0, r1]
	endif else begin

	endelse
	
	csrc = total(ss[ebound[0]:ebound[2] - 1L])
	cbkg = total(bb[ebound[0]:ebound[2] - 1L])
	
	rate[i] = (csrc - cbkg * f) / exptime
	var = csrc + cbkg * f^2d
	rate_err[i] = sqrt(var) / exptime
	print, dir + ' Total/back/soft/hard counts: ', csrc, cbkg * f, cs, ch, r, $
		format='(A, I5, F10.4, I5, I5, F5.2)'

	bkgfrac[i] = cbkg * f / double(csrc)
	; get MJD at the mid-point of the observation
	date0 = sxpar(shdr, 'DATE-OBS')
	date1 = sxpar(shdr, 'DATE-END')
	date[i] = (date_conv(date0, 'MODIFIED') + date_conv(date1, 'MODIFIED')) / 2d
endfor

print, 'background fraction:', min(bkgfrac), max(bkgfrac), median(bkgfrac)

if keyword_set(saveps) then begin
	current_device = !d.name ; save current device
	set_plot, 'ps'
	epsname = 'ulx_lc1.eps'
	device, filename=epsname, /encapsulated
endif

xr = [900, 1400]
yr = [0, 0.025]
cs = 2
fnt = 1
co = [cgcolor('red'), cgcolor('orange'), cgcolor('dark green')]

plot, xr, /nodata, charsize=cs, font=fnt, $
	xstyle=1, xrange=xr, ystyle=1, yrange=yr, $
	xmargin=[7, 2], ymargin=[3, 1], $
	xtitle='MJD - 56000', ytitle='Rate (counts s!U-1!N)'

MJD0 = 56000L
xx = date - MJD0 ; MJD
yy = rate
yerr = rate_err
y0 = yy - yerr
y1 = yy + yerr
plotsym, 0, /fill
oploterror, xx, yy, yerr, psym=8 ;, color=co[1]

if keyword_set(saveps) then begin
	device, /close
	chepslinewidth, epsname, 40
	epsname = 'ulx_hr.eps'
	device, filename=epsname, /encapsulated
endif else stop

xr = [0, 1.5]
yr = [0, 0.025]
cs = 2
fnt = 1

plot, xr, /nodata, charsize=cs, font=fnt, $
	xstyle=1, xrange=xr, ystyle=1, yrange=yr, $
	xmargin=[7, 1], ymargin=[3, 1], $
	xtitle='Hardness Ratio', ytitle='Rate (counts s!U-1!N)'

q = where(hr ne 0)

xx = hr[q]
yy = rate[q]
xerr0 = hr[q] - hr_err[q]
xerr1 = hr[q] + hr_err[q]
yerr0 = rate[q] - rate_err[q]
yerr1 = rate[q] + rate_err[q]

for i=0, n_elements(xx) - 1L do begin
	oplot, [xerr0[i], xerr1[i]], yy[i]*[1,1]
	oplot, xx[i]*[1,1], [yerr0[i], yerr1[i]]
; 	plotsym, 0, /fill
; 	plots, xx[i], yy[i], psym=8	
; 	plotsym, 0, 0.6, /fill
; 	plots, xx[i], yy[i], psym=8, color=cgcolor('white')
endfor
plotsym, 0, /fill
oplot, xx, yy, psym=8	
plotsym, 0, 0.6, /fill
oplot, xx, yy, psym=8, color=cgcolor('white')


if keyword_set(saveps) then begin
	device, /close
	chepslinewidth, epsname, 40
	set_plot, current_device
endif

stop

end
