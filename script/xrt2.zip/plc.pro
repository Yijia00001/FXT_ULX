pro plc, saveps=saveps

files = file_search('./*/flux.txt')

n_obs = n_elements(files)
xrt_date = dblarr(n_obs)
xrt_flux = dblarr(n_obs, 3)

print, 'Time', 'Flux', 'Error Range (erg/cm2/s)', $
	format='(A-21, A-10, A)'
for i = 0L, n_obs - 1L do begin
	fname = files[i]
	readcol, fname, format='A,A,D,D,D', time0, time1, flux0, flux1, flux2, /silent
	
	xrt_date[i] = (date_conv(time0[0], 'MODIFIED') + date_conv(time1[0], 'MODIFIED'))/2d
	xrt_flux[i, *] = [10d^flux0, 10d^flux1, 10d^flux2]
	
	; print, time0, flux[i, *], $
	;	format='(A, E10.2, "  (", E8.2, " - ", E8.2, ")")'	
endfor

;#################################################################
MJD0 = 56000L
flux2lum = f2l(3.4d) / 1d39 ; convert from ergs/cm2/s to 1E39 erg/s

; fit a power-law decay function
fx = xrt_date - MJD0
fy = xrt_flux[*, 0] * flux2lum
ferr = (xrt_flux[*,2] - xrt_flux[*,1]) / 2d * flux2lum ; errors

;#################################################################

if keyword_set(saveps) then begin
	current_device = !d.name ; save current device
	set_plot, 'ps'
	epsname = 'ulx_lc.eps'
	device, filename=epsname, /encapsulated
endif

xr = [930, 1080]
yr = [0, 500]
cs = 2
fnt = 1
co = [cgcolor('red'), cgcolor('orange'), cgcolor('dark green')]

plot, xr, /nodata, charsize=cs, font=fnt, $
	xstyle=1, xrange=xr, ystyle=1, yrange=yr, $
	xmargin=[6, 2], ymargin=[3, 1], $
	xtitle='MJD - 56000', ytitle='Luminosity (10!U39!N erg s!U-1!N)'


xx = xrt_date - MJD0 ; MJD
yy = xrt_flux[*, 0] * flux2lum
y0 = xrt_flux[*, 1] * flux2lum
y1 = xrt_flux[*, 2] * flux2lum

plotsym, 0, /fill
oplot, xx, yy, psym=8, color=co[1]
for i = 0L, n_elements(y0) - 1L do begin
	oplot, xx[i]*[1,1], [y0[i], y1[i]], color=co[1]
	oplot, xx[i] + (xr[1] - xr[0])*5d-3*[-1,1], y0[i]*[1,1], color=co[1]
	oplot, xx[i] + (xr[1] - xr[0])*5d-3*[-1,1], y1[i]*[1,1], color=co[1]
endfor

if keyword_set(saveps) then begin
	device, /close
	chepslinewidth, epsname, 40
	set_plot, current_device
endif

stop

end
